﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuadTree
{
    class QuadTreeImp
    {
        QuadTreeImp northWest;
        QuadTreeImp northEast;
        QuadTreeImp southWest;
        QuadTreeImp southEast;
    }
}
